import binascii
import firebase_admin
from firebase_admin import credentials, db
from PIL import Image
import os

def hex_to_jpg(hex_str, width, height):
    # Convert hex string to bytes
    hex_bytes = bytes.fromhex(hex_str)

    # Create PIL Image object from bytes
    img = Image.frombytes("RGB", (width, height), hex_bytes)

    # Save image as JPEG file
    file_name = "pulled_image.jpg"
    file_path = os.path.join("Images_pulled", file_name)
    img.save(file_path, format="JPEG")

# Fetch the service account key JSON file contents
cred = credentials.Certificate(r"C:\Users\isaia\OneDrive\Desktop\School\Spring 2023\ECEN 403\Capstone Project\Database Connection\serviceAccountKey.json")

# Initialize the app with a service account, granting admin privileges
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://iot-pet-based-tracker-database-default-rtdb.firebaseio.com/'
})

# Pull the image hex string from the database
image_ref = db.reference('Image')
image_dict = image_ref.get()
hex_str = image_dict.get('img_hex')

# Convert the hex-encoded image to a JPEG file and save to folder
hex_to_jpg(hex_str, 267, 178)
