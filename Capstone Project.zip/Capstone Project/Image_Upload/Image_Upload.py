import binascii
import firebase_admin
from firebase_admin import credentials, db
from PIL import Image

def jpeg_to_hex(file_path):
    # Open JPEG image file and convert to hex string
    with open(file_path, "rb") as f:
        jpeg_bytes = f.read()
        hex_str = binascii.hexlify(jpeg_bytes).decode()

    return hex_str

# Fetch the service account key JSON file contents
cred = credentials.Certificate(r"C:\Users\isaia\OneDrive\Desktop\School\Spring 2023\ECEN 403\Capstone Project\Database Connection\serviceAccountKey.json")

# Initialize the app with a service account, granting admin privileges
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://iot-pet-based-tracker-database-default-rtdb.firebaseio.com/'
})

# Read the image data from the JPEG file and convert to hex
hex_str = jpeg_to_hex("Images/1.jpeg")

# Upload the hex-encoded image to the database under 'Image'
image_ref = db.reference('Image')
image_ref.set({
    'img_hex': hex_str
})
