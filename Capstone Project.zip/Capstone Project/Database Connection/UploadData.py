import csv
import os
import time

import firebase_admin
from firebase_admin import credentials, firestore, db
import pandas as pd

# Fetch the service account key JSON file contents
cred = credentials.Certificate(r"C:\Users\isaia\OneDrive\Desktop\School\Spring 2023\ECEN 403\Capstone Project\Database Connection\serviceAccountKey.json")

# Initialize the app with a service account, granting admin privileges
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://iot-pet-based-tracker-database-default-rtdb.firebaseio.com/'
})

# Open csv and skip the first row
df = pd.read_csv(r'~\OneDrive\Desktop\School\Spring 2023\ECEN 403\Capstone Project\ML_Program\Clean_Data\CleanData.csv')

coords_ref = db.reference('Coords')

# Dumby variable to break out of the for loop early
x = 0
# Save first date
old_date = ''
# Iterates through rows
for i, row in df.iterrows():
    rounded_long = round(row[1], 3)
    rounded_lat = round(row[2], 3)

    if old_date == row[0][:10]:
        for i in range(3):
            date_ref = coords_ref.child(row[0][:10])
            date_ref.update({
                row[0][11:19]: {
                    'long': rounded_long,
                    'lat': rounded_lat,
                }
            })
    else:
        date_ref = coords_ref.child(row[0][:10])
        date_ref.set({
            row[0][11:19]: {
                'long': rounded_long,
                'lat': rounded_lat,
            }
        })

    old_date = row[0][:10]
    print(x)
    x += 1
    if x > 1000:
        break
